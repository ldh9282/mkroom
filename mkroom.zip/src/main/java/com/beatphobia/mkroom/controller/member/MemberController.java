package com.beatphobia.mkroom.controller.member;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.beatphobia.mkroom.domain.member.Member;
import com.beatphobia.mkroom.service.member.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	public MemberService memberService;
	
	
	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}
	
	// 회원가입페이지
	// GET /member/register
	@GetMapping("/register")
	public void showMemberRegisterPage(Model model) {
		
	}
	
	// POST /member/register
	@PostMapping("/register")
	public String insertMember(Member member, Model model) {
		memberService.insertMember(member);
		
		return "redirect:/home";
	}
	
	// 회원정보 수정페이지 
	// GET //member/modify
	@GetMapping("/modify")
	public void showMemberModifyPage(Member member, Model model) {
		model.addAttribute("member", 
				memberService.selectMember( member.getUserId() ) );
	}
	
	// POST /member/update
	@PostMapping("/update")
	public String updateMember(Member member, Model model) {
		memberService.updateMember(member);
		return "redirect:/home";
	}
	
	// POST /member/delete
	@PostMapping("/delete")
	public String deleteMember(Member member, Model model) {
		memberService.deleteMember(member.getUserId());	
		return "redirect:/home";
	}
	
	
	// 회원상세페이지
	// GET /member/detail
	@GetMapping("detail") 
	public void showMemberDetail(Member member, Model model) {
		model.addAttribute("member", 
				memberService.selectMember( member.getUserId() ));
	}
	
	// 회원목록페이지
	// GET /member/list
	@GetMapping("/list")
	public void showMemberListPage(Model model) {
		model.addAttribute("memberList",
				memberService.selectMemberList() );
	}
	
	
	// XML에 정의된 스프링 시큐리티 필터가 처리함
	// 회원 로그인 페이지
	// GET /member/login
	@GetMapping("/login")
	public void showLoginPage() {
		
	}

}
