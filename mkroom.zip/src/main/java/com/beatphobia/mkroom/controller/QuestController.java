package com.beatphobia.mkroom.controller;

import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.beatphobia.mkroom.common.fileupload.AttachFileDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingCreatorDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;
import com.beatphobia.mkroom.service.quest.QuestBookingService;

import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
@RequestMapping(value = "/quest/*")
public class QuestController {

	//인수로 들어온 데이터(사용자 입력 데이터)에서 sql의 #{}에 들어갈 값을 얻는다. 
	//반환 값은 sql 요청의 결과를 받아온다. 조회의 경우 화면으로 나갈 값이 된다. 
	
	public QuestBookingService questBookingService ;
	
	@GetMapping("/info")
	public String showQuestInfo(QuestPagingDTO questPagingDTO, Model model) {
		
		if(questPagingDTO.getLocationScope() == null) {
			questPagingDTO.setLocationScope("");
		} 
		if(questPagingDTO.getDiffScope() == null) {
			questPagingDTO.setDiffScope("");
		} 
		if(questPagingDTO.getQuestTimeScope() == null) {
			questPagingDTO.setQuestTimeScope("");
		} 
		
		model.addAttribute("questList", questBookingService.getQuestInfo(questPagingDTO));
		System.out.println("questListLength>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: " + questBookingService.getQuestInfo(questPagingDTO).size());
		model.addAttribute("locationList", questBookingService.getBranchLocationList());
		model.addAttribute("difficultyList", questBookingService.getDifficultyList());
		model.addAttribute("questTimeList", questBookingService.getQuestTimeList());
		model.addAttribute("questImageList", questBookingService.getQuestImageList());
		
		long rowAmountTotal = questBookingService.getRowAmountTotal(questPagingDTO);
		QuestPagingCreatorDTO questPagingCreatorDTO = new QuestPagingCreatorDTO(rowAmountTotal, questPagingDTO);
		model.addAttribute("pagingCreator", questPagingCreatorDTO);

		return "/anonymous/quest";
	}
	
	@GetMapping("/detail")
	public String showQuestInfoDetail(QuestDTO questDTO, Model model) {
		System.out.println("==================== 처리 전 ==========================");
		System.out.println("QuestDTO: " + questDTO);
		System.out.println("QuestDTO 필드 정보: " + questDTO.toString());
		
		//문자열의 경우 자동 주입 시 null로 처리됨. 아예 DTO에서 생성자 만들 때 if 걸고 처리하려고 했는데 받아오기가 안 된다. 
		//여기서 고치자! 
		if(questDTO.getGenre() == null) {
			questDTO.setGenre("");
		} 
		if(questDTO.getUuid() == null) {
			questDTO.setUuid("");
		}
		if(questDTO.getDetailComment() == null) {
			questDTO.setDetailComment("");
		}
		
		//QuestDTO questDetail = questBookingService.getQuestDetail(questDTO);
		model.addAttribute("questDetail", questBookingService.getQuestDetail(questDTO));
		
		//퀘스트 이름과 지점을 전달하고 그것에 대한 파일을 받는 기능 만들기. 
		model.addAttribute("questImageDetail", questBookingService.getQuestImageDetail(questDTO));
		
		return "/anonymous/questdetail";
	}
	
	@GetMapping("/input")
	public String InputQuestInfo() {
		
		return "/admin/questInput" ; 
		
	}
	
	
	
	
	@GetMapping(value = "/showImage", produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseEntity<List<AttachFileDTO>> showQuestImageList(AttachFileDTO attachFileDTO){
		
		return new ResponseEntity<List<AttachFileDTO>>(questBookingService.getQuestImageList(), HttpStatus.OK);
	}
	
	
	
	
}
