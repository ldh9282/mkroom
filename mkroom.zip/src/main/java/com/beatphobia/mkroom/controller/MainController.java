package com.beatphobia.mkroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.beatphobia.mkroom.domain.paging.QuestPagingCreatorDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;
import com.beatphobia.mkroom.service.quest.QuestBookingService;

import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
@RequestMapping(value = "/")
public class MainController {

	//인수로 들어온 데이터(사용자 입력 데이터)에서 sql의 #{}에 들어갈 값을 얻는다. 
	//반환 값은 sql 요청의 결과를 받아온다. 조회의 경우 화면으로 나갈 값이 된다. 
	public QuestBookingService questBookingService ;
	
	@GetMapping("")
	public String showQuestInfo(QuestPagingDTO questPagingDTO, Model model) {
		
		if(questPagingDTO.getLocationScope() == null) {
			questPagingDTO.setLocationScope("");
		} 
		if(questPagingDTO.getDiffScope() == null) {
			questPagingDTO.setDiffScope("");
		} 
		if(questPagingDTO.getQuestTimeScope() == null) {
			questPagingDTO.setQuestTimeScope("");
		} 
		
		model.addAttribute("questList", questBookingService.getQuestInfo(questPagingDTO));
		model.addAttribute("locationList", questBookingService.getBranchLocationList());
		model.addAttribute("difficultyList", questBookingService.getDifficultyList());
		model.addAttribute("questTimeList", questBookingService.getQuestTimeList());
		
		long rowAmountTotal = questBookingService.getRowAmountTotal(questPagingDTO);
		QuestPagingCreatorDTO questPagingCreatorDTO = new QuestPagingCreatorDTO(rowAmountTotal, questPagingDTO);
		model.addAttribute("pagingCreator", questPagingCreatorDTO);
		
		return "/testhome";
	}
	
	
}
