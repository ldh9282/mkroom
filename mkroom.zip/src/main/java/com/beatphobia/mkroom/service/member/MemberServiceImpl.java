package com.beatphobia.mkroom.service.member;

import java.util.List;

import org.springframework.stereotype.Service;

import com.beatphobia.mkroom.domain.member.Member;
import com.beatphobia.mkroom.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {
	
	private MemberMapper memberMapper;
	
	public MemberServiceImpl(MemberMapper memberMapper) {
		this.memberMapper = memberMapper;
	}
	
	@Override
	public int insertMember(Member member) {
		int cnt = memberMapper.insertMember(member);
		return cnt;
	}
	
	
	@Override
	public Member selectMember(String userId, String userPw) {
		memberMapper.selectMember(userId, userPw);
		return null;
	}

	@Override
	public int updateMember(Member member) {
		int cnt = memberMapper.updateMember(member);
		return cnt;
	}

	@Override
	public int deleteMember(String userId, String userPw) {
		int cnt = memberMapper.deleteMember(userId, userPw);
		return cnt;
	}

	@Override
	public List<Member> selectMemberList() {
		List<Member> memberList = memberMapper.selectMemberList();
		return null;
	}

	


}
