package com.beatphobia.mkroom.service.quest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beatphobia.mkroom.common.fileupload.AttachFileDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;
import com.beatphobia.mkroom.mapper.QuestBookingFileMapper;
import com.beatphobia.mkroom.mapper.QuestBookingMapper;

@Service
public class QuestBookingServiceImpl implements QuestBookingService{

	//인수로 들어온 데이터(사용자 입력 데이터)에서 sql의 #{}에 들어갈 값을 얻는다. 
	//반환 값은 sql 요청의 결과를 받아온다. 조회의 경우 화면으로 나갈 값이 된다. 

	private QuestBookingMapper questBookingMapper ;
	private QuestBookingFileMapper questBookingFileMapper;
	
	public QuestBookingServiceImpl(QuestBookingMapper questBookingMapper, QuestBookingFileMapper questBookingFileMapper) {
		this.questBookingMapper = questBookingMapper;
		this.questBookingFileMapper = questBookingFileMapper;
	}
	
//	public QuestBookingServiceImpl(QuestBookingMapper questBookingMapper) {
//		this.questBookingMapper = questBookingMapper;
//	}
	
	//퀘스트 정보 조회
	@Override
	public List<QuestDTO> getQuestInfo(QuestPagingDTO questPagingDTO) {
		
		System.out.println(">>>>>>>>>questPagingDTO: " + questPagingDTO);
		
//		List<QuestDTO> questList = questBookingMapper.selectQuestInfo(questPagingDTO);
		
//		System.out.println(">>>>>>>>>questList: " + questList);
//		System.out.println("questList: " + questList.get(0).getQuestName());
		return questBookingMapper.selectQuestInfo(questPagingDTO);
	}

	//DB에 저장된 총 행수 얻어오기
	@Override
	public long getRowAmountTotal(QuestPagingDTO questPagingDTO) {
		return questBookingMapper.selectRowAmountTotal(questPagingDTO);
	}
	
	//DB에 저장된 location을 중복 제거해서 가져오기(갯수말고 무엇이 존재하는지 확인)
	@Override
	public List<QuestDTO> getBranchLocationList() {
		return questBookingMapper.selectBranchLocationList();
	}
	
	//DB에 저장된 difficulty를 중복 제거해서 가져오기
	@Override
	public List<QuestDTO> getDifficultyList() {
		return questBookingMapper.selectDifficultyList();
	}
	
	//DB에 저장된 questTime을 중복 제거해서 가져오기
	@Override
	public List<QuestDTO> getQuestTimeList() {
		System.out.println("sssss" +  questBookingMapper.selectQuestTimeList());
		return questBookingMapper.selectQuestTimeList();
	}
	
	//퀘스트 상세 정보 조회
	@Override
	public QuestDTO getQuestDetail(QuestDTO questDTO) {
		System.out.println("==============================================");
		System.out.println("questDTO 필드 정보: " + questDTO.toString());
		QuestDTO questDetail = questBookingMapper.selectQuestInfoDetail(questDTO);
		
		System.out.println("questDetail 필드 정보: " + questDetail);
		return questDetail;
	}

	//DB에 저장된 이미지정보 전부 조회
	@Override
	public List<AttachFileDTO> getQuestImageList(){
		return questBookingFileMapper.selectQuestImageList();
	}
	
	//상세 페이지 호출 시, DB에 저장된 이미지정보 하나 조회
	@Override
	public AttachFileDTO getQuestImageDetail(QuestDTO questDTO) {
		return questBookingFileMapper.selectQuestImageDetail(questDTO);
	}

	//AttachFileDTO에 저장된 파일 정보를 DB에 입력
	@Override
	public void registerQuestFile(AttachFileDTO attachFileDTO) {
		questBookingFileMapper.insertQuestFile(attachFileDTO);
	}
	
	
	
	
//	@Override
//	public List<BookingDataDTO> getBookingInfo(String username) {
//		
//		List<BookingDataDTO> bookingDetail = QuestBookingMapper.selectBookingInfo(username);
//		
//		return null;
//	}







	
	
}
