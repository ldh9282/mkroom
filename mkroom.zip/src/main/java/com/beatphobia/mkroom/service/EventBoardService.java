package com.beatphobia.mkroom.service;

import java.util.List;

import com.beatphobia.mkroom.common.paging.EventBoardPagingDTO;
import com.beatphobia.mkroom.domain.fileinfo.FileInfoDTO;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEvent;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEventAttachfiles;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEventDTO;

public interface EventBoardService {

	//게시물 목록 조회
	public List<NoticeEvent> getBoardList(EventBoardPagingDTO eventBoardPagingDTO);
	
    public long getRowAmountTotal(EventBoardPagingDTO eventBoardPagingDTO) ;


	
    //특정 게시물 조회(조회수 증가 고려)
    public NoticeEvent getBoard(long bno);

    //게시물 등록 - selectKey 이용
    public Long registerBoard(NoticeEvent noticeEvent);
    
    //특정 게시물 수정
    public boolean modifyBoard(NoticeEvent noticeEvent);
    
    //특정 게시물 삭제 - 실제 삭제 
    public boolean removeBoard(long bno);
    
    //특정 게시물 삭제 요청 - 해당 글의 bdelFlag을 1로 수정 
    public boolean setBoardDeleted(long bno);
    
    //게시물 삭제(관리자) – 사용자 삭제 요청된 게시물(bdelFlag = 1) 전체 삭제
    public int removeAllDeletedBoard();
    
    //특정 게시물 조회 시, 게시물의 첨부파일 정보를 조회
    public List<NoticeEventAttachfiles> getAttachFiles(long bno) ;
    
    //게시물 조회: 게시물 조회 페이지 -> 게시물 수정 페이지 호출(by bno), 조회수 변화 없음
    //게시물 조회: 게시물 수정 후 -> 게시물 조회 페이지 호출(by bno), 조회수 증가 없음
    public NoticeEvent getBoardDetailModify(long bno) ;

	long registerFile(FileInfoDTO fileInfo, NoticeEventDTO noticeEvent);

	

	
	
	
}//end
