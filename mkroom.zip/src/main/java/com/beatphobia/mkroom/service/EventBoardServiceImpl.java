package com.beatphobia.mkroom.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.beatphobia.mkroom.domain.fileinfo.FileInfoDTO;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEvent;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEventAttachfiles;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEventDTO;
import com.beatphobia.mkroom.mapper.EventBoardAttachMapper;
import com.beatphobia.mkroom.mapper.EventBoardMapper;
import com.beatphobia.mkroom.mapper.EventFileMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class EventBoardServiceImpl implements EventBoardService {
	
	//매퍼 인터페이스 주입
	private EventBoardMapper eventBoardMapper ;
	
	private EventFileMapper eventFileMapper ;
	
	private EventBoardAttachMapper eventBoardAttachMapper;
	
	public EventBoardServiceImpl(EventBoardMapper eventBoardMapper,
								 EventFileMapper eventFileMapper,
								 EventBoardAttachMapper eventBoardAttachMapper) {
		this.eventBoardMapper = eventBoardMapper;
		this.eventFileMapper = eventFileMapper;
		this.eventBoardAttachMapper = eventBoardAttachMapper;
	}
	
	
	
	
	//게시물 목록 조회
	@Override
	public List<NoticeEvent> getBoardList(com.beatphobia.mkroom.common.paging.EventBoardPagingDTO eventBoardPagingDTO) {
		System.out.println("service: " + eventBoardMapper.selectEventBoardList(eventBoardPagingDTO));
		
		
		return eventBoardMapper.selectEventBoardList(eventBoardPagingDTO);
	}
	
	@Override
	public long getRowAmountTotal(com.beatphobia.mkroom.common.paging.EventBoardPagingDTO eventBoardPagingDTO) {
		return eventBoardMapper.selectRowAmountTotal(eventBoardPagingDTO) ;
	}
	
	
	//특정 게시물 조회 (조회수증가 1)
	@Override
	public NoticeEvent getBoard(long bno) {
		eventBoardMapper.updateBviewsCnt(bno);
		return eventBoardMapper.selectEventBoard(bno);
	}
	//게시물 마지막 bno 얻기 
    public long getFilnalBno() {
    	return eventBoardAttachMapper.selectFilnalBno();
    }
    
	//게시물 등록
	@Override
	public Long registerBoard(NoticeEvent noticeEvent) {
		log.info("서비스로 전달된 NoticeEvent: " + noticeEvent);
		
		eventBoardMapper.insertEventBoard(noticeEvent) ;
		//log.info("등록된 게시물의 bno 값: " + myBoard.getBno());
		
		//첨부파일이 없는 경우, 메서드 종료
		if (noticeEvent.getEventAttachfiles() == null || noticeEvent.getEventAttachfiles().size() <= 0) {
			return noticeEvent.getBno();
		}
		
		//첨부파일이 있는 경우, myBoard의 bno 값을 첨부파일 정보 VO에 저장 후, tbl_myAttachFiles 테이블에 입력
		noticeEvent.getEventAttachfiles().forEach(
				
				attachFile -> {
					attachFile.setBno(noticeEvent.getBno()) ;
					eventFileMapper.insertAttachFile(attachFile);
				}
		);
		
		return noticeEvent.getBno();
	}
	
	//게시물 파일 등록
	@Override
	@Transactional
	public long registerFile(FileInfoDTO fileInfo, NoticeEventDTO noticeEvent) {
		
		//첨부파일이 없는 경우, 메서드 종료
		if (fileInfo == null) {
			//첨부파일이 없을 때 내용 등록만하고 bno 반환, 메서드 종료. 
			return 0;
		}
		
		System.out.println("noticeEvent<<<<<<<<<<<<: " + noticeEvent);
		System.out.println("fileInfo<<<<<<<<<<<<: " + fileInfo);
		
		//첨부파일이 있을 경우, 첨부파일 등록 후 bno 반환, 메서드 종료
		
		System.out.println("fileInfo2222<<<<<<<<<<<<: " + fileInfo);
		eventBoardAttachMapper.insertAttachFile(fileInfo);
		System.out.println("fileInfo33333<<<<<<<<<<<<: " + fileInfo);
		eventBoardAttachMapper.insertAttachtag(noticeEvent, fileInfo);
		System.out.println("fileInfo44444<<<<<<<<<<<<: " + fileInfo);
		
		return 1;
	}

	//게시물 수정
	@Override
	public boolean modifyBoard(NoticeEvent noticeEvent) {
		log.info("서비스로 전달된 NoticeEvent: " + noticeEvent);
		
		long bno = noticeEvent.getBno() ;
		
		//게시물 변경 시, 기존 첨부파일이 삭제와 새로운 첨부파일 추가를 모두 고려하여, 기존 DB의 정보를 모두 삭제 후,
		//첨부파일 정보를 DB에 다시 추가하는 방식으로 처리합니다.
		//기존 DB 첨부파일 정보 삭제
		
		
		boolean boardModfyResult = eventBoardMapper.updateEventBoard(noticeEvent) == 1 ;
		
		if ( (boardModfyResult && noticeEvent.getEventAttachfiles() != null)) {
			eventFileMapper.deleteBoardAllAttachFiles(bno);
			noticeEvent.getEventAttachfiles().forEach(
					
					attachFile -> {
						attachFile.setBno(bno) ;
						eventFileMapper.insertAttachFile(attachFile) ;
					}
			);	
			
		}
		
		return boardModfyResult;
	}

	//특정 게시물 삭제
	@Transactional
	@Override
	public boolean removeBoard(long bno) {
		eventFileMapper.deleteBoardAllAttachFiles(bno);
		log.info("서비스로 전달된 bno: " + bno);
		return eventBoardMapper.deleteEventBoard(bno) == 1;
	}

	//특정 게시물 삭제 요청 - 해당 글의 bdelFlag을 1로 수정
	@Transactional
	@Override
	public boolean setBoardDeleted(long bno) {
		log.info("서비스로 전달된 bno: " + bno);
		//myBoardAttachFileMapper.deleteBoardAllAttachFiles(bno);
		return eventBoardMapper.updateBdelFlag(bno) == 1;
	}

	//게시물 전부삭제 (관리자 bdelflag 1)
	@Override
	public int removeAllDeletedBoard() {

		return eventBoardMapper.deleteAllEventBoard();
	}
	
	//특정 게시물 조회 시, 게시물의 첨부파일 정보를 조회
	@Override
	public List<NoticeEventAttachfiles> getAttachFiles(long bno) {
		
		return eventFileMapper.selectBoardAttachFileList(bno) ;
		
	}
	
	//게시물 조회: 게시물 조회 페이지 -> 게시물 수정 페이지 호출(by bno), 조회수 변화 없음
    //게시물 조회: 게시물 수정 후 -> 게시물 조회 페이지 호출(by bno), 조회수 증가 없음
	@Override
	public NoticeEvent getBoardDetailModify(long bno) {
		return eventBoardMapper.selectEventBoard(bno) ;
	}





}
