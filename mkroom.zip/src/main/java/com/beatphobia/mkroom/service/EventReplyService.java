package com.beatphobia.mkroom.service;

import com.beatphobia.mkroom.domain.noticeevent.EventReply;
import com.beatphobia.mkroom.domain.paging.EventReplyCreatorDTO;
import com.beatphobia.mkroom.domain.paging.EventReplyDTO;

public interface EventReplyService {
	public EventReplyCreatorDTO getEventReplyList(EventReplyDTO EventReplyDTO);
	public long registerEventReplyForBoard(EventReply EventReply);
	public long registerEventReplyForReply(EventReply EventReply);
	public EventReply getEventReply(long bno, long rno);
	public int modifyEventReply(EventReply EventReply);
	public int removeEventReply(long bno, long rno);
}
