package com.beatphobia.mkroom.service.quest;

import java.util.List;

import com.beatphobia.mkroom.common.fileupload.AttachFileDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;

public interface QuestBookingService {

	//인수로 들어온 데이터(사용자 입력 데이터)에서 sql의 #{}에 들어갈 값을 얻는다. 
	//반환 값은 sql의 결과를 받아온다. 조회의 경우 화면으로 나갈 값이 된다. 
	
	//퀘스트 정보 조회
	public List<QuestDTO> getQuestInfo(QuestPagingDTO questPagingDTO);
	
	//DB에 저장된 총 행수 얻어오기
	public long getRowAmountTotal(QuestPagingDTO questPagingDTO);
	
	////DB에 저장된 location을 중복 제거해서 가져오기
	public List<QuestDTO> getBranchLocationList();
	
	//DB에 저장된 difficulty를 중복 제거해서 가져오기
	public List<QuestDTO> getDifficultyList();
	
	//DB에 저장된 questTime을 중복 제거해서 가져오기
	public List<QuestDTO> getQuestTimeList();
	
	//퀘스트 상세 정보 조회
	public QuestDTO getQuestDetail(QuestDTO questDTO);
	
	//DB에 저장된 이미지정보 전부 조회
	public List<AttachFileDTO> getQuestImageList();
	
	//상세 페이지 호출 시, DB에 저장된 이미지정보 하나 조회
	public AttachFileDTO getQuestImageDetail(QuestDTO questDTO);
	
	//AttachFileDTO에 저장된 파일 정보를 DB에 입력
	public void registerQuestFile(AttachFileDTO attachFileDTO);
	
	
	//예약 정보 조회
//	public List<BookingDataDTO> getBookingInfo(String username);
	
	//리뷰 조회
	
	
	//리뷰 입력
	
	
}
