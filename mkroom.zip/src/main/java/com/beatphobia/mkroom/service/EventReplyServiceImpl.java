package com.beatphobia.mkroom.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.beatphobia.mkroom.domain.noticeevent.EventReply;
import com.beatphobia.mkroom.domain.paging.EventReplyCreatorDTO;
import com.beatphobia.mkroom.domain.paging.EventReplyDTO;
import com.beatphobia.mkroom.mapper.EventBoardMapper;
import com.beatphobia.mkroom.mapper.EventReplyMapper;

@Service
public class EventReplyServiceImpl implements EventReplyService{
	private EventReplyMapper EventReplyMapper;
	private EventBoardMapper EventBoardMapper;
	
	public EventReplyServiceImpl(EventReplyMapper EventReplyMapper,
									EventBoardMapper EventBoardMapper) {
		this.EventReplyMapper=EventReplyMapper;
		this.EventBoardMapper=EventBoardMapper;
	}
	@Override
	public EventReplyCreatorDTO getEventReplyList(EventReplyDTO EventReplyDTO) {
		long replyTotalCnt=EventReplyMapper.selectEventReplyTotalCnt(EventReplyDTO);
		int pageNum=EventReplyDTO.getPageNum();
		EventReplyCreatorDTO EventReplyCreatorDTO=null;
		if(replyTotalCnt==0) {
			EventReplyDTO.setPageNum(1);
			EventReplyCreatorDTO=new EventReplyCreatorDTO(0, EventReplyDTO, EventReplyMapper.selectEventReplyList(EventReplyDTO));
		}else {
			if(pageNum==-10) {
				pageNum=(int)Math.ceil(replyTotalCnt/(EventReplyDTO.getRowAmountPerPage()*1.0));
				EventReplyDTO.setPageNum(pageNum);
			}
			EventReplyCreatorDTO=new EventReplyCreatorDTO(EventReplyMapper.selectEventReplyTotalCnt(EventReplyDTO), EventReplyDTO, EventReplyMapper.selectEventReplyList(EventReplyDTO));
		}
		return EventReplyCreatorDTO;
	}
	@Override
	@Transactional
	public long registerEventReplyForBoard(EventReply EventReply) {
		EventReplyMapper.insertEventReplyForBoard(EventReply);
		EventBoardMapper.updateBReplyCnt(EventReply.getBno(),1);
		return EventReply.getRno();
	}
	@Override
	@Transactional
	public long registerEventReplyForReply(EventReply EventReply) {
		EventReplyMapper.insertEventReplyForReply(EventReply);
		EventBoardMapper.updateBReplyCnt(EventReply.getBno(),1);
		return EventReply.getBno();
	}
	@Override
	public EventReply getEventReply(long bno, long rno) {
		return EventReplyMapper.selectEventReplySearch(bno, rno);
	}
	@Override
	public int modifyEventReply(EventReply EventReply) {
		return EventReplyMapper.updateEventReply(EventReply);
	}
	@Override
	@Transactional
	public int removeEventReply(long bno, long rno) {
		int delRowCnt=EventReplyMapper.deleteEvenetReply(bno, rno);
		EventBoardMapper.updateBReplyCnt(bno,-1);
		return delRowCnt;
	}
}
