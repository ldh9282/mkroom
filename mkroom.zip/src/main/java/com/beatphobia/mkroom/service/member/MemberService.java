package com.beatphobia.mkroom.service.member;

import java.util.List;

import org.springframework.stereotype.Service;

import com.beatphobia.mkroom.domain.member.Member;

public interface MemberService {

	int insertMember(Member member);
	
	Member selectMember(String userId, String userPw);

	int updateMember(Member member);
	
	int deleteMember(String userId, String userPw);

	List<Member> selectMemberList();


	

}
