package com.beatphobia.mkroom.domain.paging;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class QuestPagingDTO {

	private int pageNum;
	private int rowAmountPerPage;
	private String diffScope;
	private String locationScope;
	private String questTimeScope;
	
	//검색 처리를 위한 메서드
//	public String[] getScopeArray() {
//		//scope 가 null이면 빈 문자열 배열을 반환, scope 가 null이 아니면 받아온 문자열을 하나씩 쪼갠다. 
//		//.split()은 공백을 하나로 보고 처리하지만, .split(" ")은 하나의 공백을 구분자로 처리하며, 
//		//.split("")은 글자 사이를 구분자로 처리하므로 문자열을 모두 하나씩 쪼개어 배열 요소에 저장한다. 
//		return (this.scope == null) ? (new String[] {}) : (this.scope.split(""));
//	}
	
	//인수 전달 없이 처음 페이지를 호출할 때 기본 값. 
	public QuestPagingDTO() {
		this.pageNum = 1;
		this.rowAmountPerPage = 5;
	}
	
	//페이지 번호 클릭 시
	public QuestPagingDTO(int pageNum) {
		
		if(pageNum <= 0) {
			this.pageNum = 1;
		} else {
			this.pageNum = pageNum;
		}
	
		this.rowAmountPerPage = 5;
	}
	
	//행 갯수 선택 시, 현재 페이지 번호와 갯수 전달. 
	public QuestPagingDTO(int pageNum, int rowAmountPerPage) {
		
		if(pageNum <= 0) {
			this.pageNum = 1;
		} else {
			this.pageNum = pageNum;
		}
	
		if(rowAmountPerPage <= 0) {
			this.rowAmountPerPage = 10;
		} else {
			this.rowAmountPerPage = rowAmountPerPage;
		}
		
	}
	
	
	
}
