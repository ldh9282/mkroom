package com.beatphobia.mkroom.domain.paging;

import java.util.List;

import com.beatphobia.mkroom.domain.noticeevent.EventReply;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class EventReplyCreatorDTO {
	private EventReplyDTO EventReplyDTO;
	private int startPagingNum ;
	private int endPagingNum ;
	private boolean prev ;
	private boolean next ;
	private long rowAmountTotal ;
	private int pagingNumCnt ; 
	private int lastPageNum ;
	
	private List<EventReply> replyList;
	
	public EventReplyCreatorDTO(long rowAmountTotal, EventReplyDTO EventReplyDTO, List<EventReply> replyList) {
		this.EventReplyDTO=EventReplyDTO;
		this.rowAmountTotal=rowAmountTotal;
		this.replyList=replyList;
		this.pagingNumCnt=5;
		
		this.endPagingNum=(int)(Math.ceil(EventReplyDTO.getPageNum()/(this.pagingNumCnt*1.0)))*this.pagingNumCnt;
		this.startPagingNum=this.endPagingNum-(this.pagingNumCnt-1);
		this.lastPageNum=(int)(Math.ceil((rowAmountTotal*1.0)/EventReplyDTO.getRowAmountPerPage()));
		if(this.lastPageNum<this.endPagingNum) {
			this.endPagingNum=this.lastPageNum;
		}
		this.prev=this.startPagingNum>1;
		this.next=this.endPagingNum<this.lastPageNum;
	}
}
