package com.beatphobia.mkroom.domain.booking;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuestBookingData {
//	BOOKINGNUM	NUMBER(10,0)	
//	QUESTNAME	VARCHAR2(100 BYTE)	
//	BRANCHLOCATION	VARCHAR2(200 BYTE)	
//	SELECTTIME	NUMBER(2,0)	
//	TEAMMEMBER	VARCHAR2(1000 BYTE)
	
	private long bookingNum;
	private String questName;
	private String branchLocation;
	private Date selectTime;
	private String teamMemer;
	
}
