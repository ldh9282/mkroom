package com.beatphobia.mkroom.domain.noticeevent;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class NoticeEventReply {
//	RNO NUMBER (10)
//	BNO NUMBER (10)
//	RCONTENT VARCHAR2 (4000 BYTE)
//	RWRITER VARCHAR2 (100 BYTE)
//	RREGDATE DATE
//	RMODDATE TIMESTAMP (0)
//	PRNO NUMBER (10)

	private long rno;
	private long bno;
	private String rcontent;
	private String rwriter;
	private String rregDate;
	private String rmodDate;
	private long prno;
	private int lvl;
	
}
