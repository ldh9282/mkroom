package com.beatphobia.mkroom.domain.quest;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class QuestDTO {
	
	private String questName;
	private int maxPlayerNum;
	private String genre;
	private int difficulty;
	private String branchLocation;
	private String uuid;
	private int delFlag;
	private String detailComment;
	private int minPlayerNum;
	private int questTime;
	
}
