package com.beatphobia.mkroom.common.fileupload;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/files")
public class FileRestController {
	// To save in relative path
	@Autowired
	private HttpServletRequest request;
	
	@PostMapping("/upload")
	public ResponseEntity<String> handleUpload(@RequestParam("files") MultipartFile[] files) {
		
		if (files == null) {
			return ResponseEntity.badRequest().body("File upload failed");
		}
		
		for (MultipartFile file : files) {
			if (!file.isEmpty()) {
				// Save files in webapp/uploads (relative path)
				String dirToUpload = "/uploads/";
				String realPathtoUpload = request.getServletContext().getRealPath(dirToUpload);
				// Test and Remove
				System.out.println("저장 경로 >>> " + realPathtoUpload);
			
				if (!new File(realPathtoUpload).exists()) {
					new File(realPathtoUpload).mkdir();
				}
				
				String originalName = file.getOriginalFilename();
				String filePath = realPathtoUpload + originalName;
				File dest = new File(filePath);
				
				try {
					file.transferTo(dest);
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		return ResponseEntity.ok("File uploaded successfully");
	}
	
	@GetMapping("/download")
	public ResponseEntity<Resource> handleFileDownload(String fileName) {
		// Download the file from the desired location
		
		String dirToUpload = "/uploads/";
		String realPathtoUpload = request.getServletContext().getRealPath(dirToUpload);
		
		Resource resource = new FileSystemResource(realPathtoUpload + fileName);
		
		if(!resource.exists()) {
			return new ResponseEntity<Resource>(HttpStatus.NOT_FOUND) ;
			
		} 
		
		
		String fileNameToDownload = null;
		
		try {
			fileNameToDownload = URLEncoder.encode(resource.getFilename(), "utf-8");
			fileNameToDownload = fileNameToDownload.replace("+", "%20");
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		HttpHeaders httpHeaders = new HttpHeaders();
		
		httpHeaders.add("Content-Disposition", "attachment; fileName=" + fileNameToDownload) ;
		return new ResponseEntity<Resource>(resource, httpHeaders, HttpStatus.OK) ;
		
	}
	
}
