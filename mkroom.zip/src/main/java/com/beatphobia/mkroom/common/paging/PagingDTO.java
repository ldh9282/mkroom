package com.beatphobia.mkroom.common.paging;

import org.springframework.beans.factory.annotation.Value;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PagingDTO {
	private int pageNum;
	private int rowAmountPerPage;
	
	
	public PagingDTO(@Value("1") int pageNum, @Value("10") int rowAmountPerPage) {
		this.pageNum = pageNum;
		this.rowAmountPerPage = rowAmountPerPage;
	}
	
	
}
