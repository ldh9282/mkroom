package com.beatphobia.mkroom.common.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.beatphobia.mkroom.domain.member.Member;
import com.beatphobia.mkroom.mapper.MemberMapper;

public class MemberUserDetailsService
			implements UserDetailsService {

	private MemberMapper memberMapper;

	public void setMemberMapper(MemberMapper memberMapper) {
		this.memberMapper = memberMapper;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Member member = memberMapper.selectMember(username);
		return member == null ?
				null : new MemberUser(member);
	}
	
	
}
