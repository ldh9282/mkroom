package com.beatphobia.mkroom.common.payment;

import java.sql.Timestamp;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PaymentData {
	
	private String imp_uid; // 결제번호
	private String merchant_uid; // 주문번호
	private String name;	// 제품명
	private String paid_amount;	// 결제금액
	private Date paid_at;	// 시간
	
	private String buyer_id;
	private String buyer_name;
	private String buyer_tel;
	private String buyer_email;
	private String buyer_addr;
	private String buyer_postcode;
	
	

	
	
}
