package com.beatphobia.mkroom.common.booking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookingRestController {

	@PostMapping("/validateBooking")
	public ResponseEntity<String> validateBooking(@RequestBody Map<String, String> data) {
		
		System.out.println(">>> " + data.get("dateStr"));
		Date date = new Date(Long.parseLong(data.get("dateStr")));
		System.out.println(">>>" + date);
		
		return new ResponseEntity<String>("ok" , HttpStatus.OK);
	}
}
