package com.beatphobia.mkroom.common.mail;

import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MailRestController {
	@PostMapping("/sendEmail")
	public ResponseEntity<String> sendEmail(@RequestBody Map<String, String> data) {
		
		System.out.println(">>> "  + data.get("name"));
		System.out.println(">>> "  + data.get("email"));
		System.out.println(">>> "  + data.get("subject"));
		System.out.println(">>> "  + data.get("message"));
		
		
		String username = "contactMkroom@gmail.com";
		String password = "zdfcxiegwpofdoam";
		// refer : https://stackoverflow.com/questions/10509699/must-issue-a-starttls-command-first
		// SMTP = smtp.gmail.com 
		// Port = 465
		Properties prop = new Properties();
		prop.setProperty("mail.transport.protocol", "smtp");
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "465");
		prop.put("mail.smtp.auth", "true");	
		prop.put("mail.smtp.socketFactory.port", "465");  
	    prop.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
	    prop.put("mail.smtp.socketFactory.fallback", "false");
		
		Session session = Session.getInstance(prop, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
		});
		// Header 추가 설정
        HttpHeaders resHeaders = new HttpHeaders();
        resHeaders.add("Content-Type", "text/plain;charset=UTF-8");
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(data.get("email"), data.get("name"), "UTF-8"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(username));
			message.setSubject(data.get("subject"));
			message.setText("이름: " + data.get("name") + "\n이메일: " + data.get("email") + "\n메시지: " + data.get("message"));
			Transport.send(message);
			
		} catch (Exception e) {
			System.out.println(e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					             .headers(resHeaders)
					             .body("메일전송이 실패하였습니다");	
		}
		
		
		return ResponseEntity.status(HttpStatus.OK)
				             .headers(resHeaders)
				             .body("메일이 전송되었습니다");
	}
}
