package com.beatphobia.mkroom.common.payments;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaymentRestController {
	
	@PostMapping("/payment/complete")
	public ResponseEntity<String> complete(@RequestBody PaymentData paymentData) {
		System.out.println(paymentData);
		return ResponseEntity.ok("success");
	}	
	
}
