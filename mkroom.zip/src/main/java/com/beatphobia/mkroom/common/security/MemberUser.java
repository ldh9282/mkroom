package com.beatphobia.mkroom.common.security;

import java.util.Collection;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.beatphobia.mkroom.domain.member.Member;

public class MemberUser extends User {

	private static final long serialVersionUID = 1L;
	
	private Member member;

	public MemberUser(Member member) {
		super(
				member.getUserId(),
				member.getUserPw(),
				member.getAuthorityList().stream().map((auth) -> {
					return new SimpleGrantedAuthority(auth.getAuthority());
				})
				.collect(Collectors.toList())
				
				);
		this.member = member;
	}
	
	
}
