package com.beatphobia.mkroom.mapper;

import java.util.List;

import com.beatphobia.mkroom.domain.member.Member;

public interface MemberMapper {

	int insertMember(Member member);
	
	void selectMember(String userId, String userPw);

	int updateMember(Member member);

	int deleteMember(String userId, String userPw);

	List<Member> selectMemberList();




}
