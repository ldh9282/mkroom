package com.beatphobia.mkroom.mapper;

import java.util.List;

import com.beatphobia.mkroom.domain.booking.BookingDataDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingCreatorDTO;
import com.beatphobia.mkroom.domain.paging.QuestPagingDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;

public interface QuestBookingMapper {
	
	//인수로 들어온 데이터(사용자 입력 데이터)에서 sql의 #{}에 들어갈 값을 얻는다. 
	//반환 값은 sql의 결과를 받아온다. 조회의 경우 화면으로 나갈 값이 된다. 
	
	//퀘스트 정보 조회
	public List<QuestDTO> selectQuestInfo(QuestPagingDTO questPagingDTO);
	
	//DB에 저장된 총 행수 얻어오기
	public long selectRowAmountTotal(QuestPagingDTO questPagingDTO);
	
	//DB에 저장된 location을 중복 제거해서 가져오기(갯수말고 무엇이 존재하는지 확인)
	public List<QuestDTO> selectBranchLocationList();
	
	//DB에 저장된 difficulty를 중복 제거해서 가져오기
	public List<QuestDTO> selectDifficultyList();
	
	//DB에 저장된 questTime을 중복 제거해서 가져오기
	public List<QuestDTO> selectQuestTimeList();
	
	//퀘스트 상세 정보 조회
	public QuestDTO selectQuestInfoDetail(QuestDTO questDTO);
	
//	//특정 지점에 대한 퀘스트 정보 조회
//	public List<QuestDTO> selectLocationConditionList();
//	
//	//특정 난이도에 대한 퀘스트 정보 조회
//	public List<QuestDTO> selectDifficultyConditionLList();	
//	
//	//특정 제한시간에 대한 퀘스트 정보 조회
//	public List<QuestDTO> selectQuestTimeConditionList();		
	
	
	//예약 정보 조회
//	public List<BookingDataDTO> selectBookingInfo(String username);
	
	//예약 정보 입력
	
	
	
	
	
}
