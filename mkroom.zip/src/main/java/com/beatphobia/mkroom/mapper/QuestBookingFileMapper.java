package com.beatphobia.mkroom.mapper;

import java.util.List;

import com.beatphobia.mkroom.common.fileupload.AttachFileDTO;
import com.beatphobia.mkroom.domain.quest.QuestDTO;

public interface QuestBookingFileMapper {
	

	//DB에 저장된 이미지정보 전부 조회
	public List<AttachFileDTO> selectQuestImageList();
	
	//상세 페이지 호출 시, DB에 저장된 이미지정보 하나 조회
	public AttachFileDTO selectQuestImageDetail(QuestDTO questDTO);
	
	//AttachFileDTO에 저장된 파일 정보를 DB에 입력
	public void insertQuestFile(AttachFileDTO attachFileDTO);
	

	
}
