package com.beatphobia.mkroom.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.beatphobia.mkroom.domain.noticeevent.EventReply;
import com.beatphobia.mkroom.domain.paging.EventReplyDTO;

public interface EventReplyMapper {
 public List<EventReply> selectEventReplyList(EventReplyDTO EventReplyDTO);
 public long selectEventReplyTotalCnt(EventReplyDTO EventReplyDTO);
 public long insertEventReplyForBoard(EventReply EventReply);
 public long insertEventReplyForReply(EventReply EventReply);
 public EventReply selectEventReplySearch(@Param("bno") long bno, @Param("rno") long rno);
 public int updateEventReply(EventReply EventReply);
 public int deleteEvenetReply(@Param("bno") long bno, @Param("rno") long rno);
}
