package com.beatphobia.mkroom.mapper;

import java.util.List;

import com.beatphobia.mkroom.domain.noticeevent.NoticeEventAttachfiles;

public interface EventFileMapper {

	
	public void insertAttachFile(NoticeEventAttachfiles noticeEventAttachfiles) ;
	
	public List<NoticeEventAttachfiles> selectBoardAttachFileList(long bno) ;
	
	public void deleteAttachFile(String uuid) ;
	
	public void deleteBoardAllAttachFiles(long bno) ;
	
	public List<NoticeEventAttachfiles> selectAttachFilesBeforeOneDay() ;

	
	
}
