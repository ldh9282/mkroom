package com.beatphobia.mkroom.mapper;

import java.util.List;

import com.beatphobia.mkroom.domain.fileinfo.FileInfoDTO;
import com.beatphobia.mkroom.domain.noticeevent.NoticeEventDTO;

public interface EventBoardAttachMapper {

	//게시물 정보가 저장된 테이블의 마지막 bno 얻기
	public long selectFilnalBno();
	
	//첨부파일 추가(연결 테이블 + 파일정보 테이블)
	public void insertAttachtag(NoticeEventDTO noticeEvent, FileInfoDTO fileInfoDTO);
	public void insertAttachFile(FileInfoDTO fileInfoDTO);
	
	//특정 게시물의 모든 첨부파일 조회
	public List<NoticeEventDTO> selectBoardAttachFileList(long bno);
	
	//특정 첨부파일 삭제
	public void deleteAttachFile(String uuid) ;
	
	//특정 게시물의 모든 첨부파일 삭제
	public void deleteBoardAllAttachFiles(long bno) ;

	
	
    
}
