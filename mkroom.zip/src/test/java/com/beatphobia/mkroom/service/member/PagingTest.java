package com.beatphobia.mkroom.service.member;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.beatphobia.mkroom.common.paging.PagingDTO;
import com.beatphobia.mkroom.mapper.MemberMapper;

import lombok.Setter;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/mybatis-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"
})

public class PagingTest {
	
	@Setter(onMethod_ = @Autowired)
	private MemberService memberService;
	
	@Test
	public void pagingTest() {
		PagingDTO pagingDTO = new PagingDTO();
		pagingDTO.setPageNum(1);
		pagingDTO.setScope("N");
		pagingDTO.setKeyword("user1");
		memberService.selectMemberListPaging(pagingDTO).forEach((member) -> {
		
			System.out.println(">>>" + member.getUserId());
		});
	}
}
