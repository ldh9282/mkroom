package com.beatphobia.mkroom.service.member;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.beatphobia.mkroom.common.paging.PagingCreatorDTO;
import com.beatphobia.mkroom.mapper.MemberMapper;

import lombok.Setter;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/mybatis-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"
})

public class SelectMemberListTest {

	@Setter(onMethod_ = @Autowired)
	private MemberMapper memberMapper;
//	
//	public void selectMemberListPaging() {
//		PagingCreatorDTO pagingCreatorDTO = new PagingCreatorDTO(, null)
//		memberMapper
//	}
}
