package com.beatphobia.mkroom.service.member;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.beatphobia.mkroom.domain.member.Member;
import com.beatphobia.mkroom.domain.member.MemberAuthority;
import com.beatphobia.mkroom.mapper.MemberMapper;

import lombok.Setter;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/mybatis-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"
	
})
public class InsertMemberTest {
	@Setter(onMethod_ = @Autowired)
	private MemberMapper memberMapper;
	@Setter(onMethod_ = @Autowired)
	private BCryptPasswordEncoder encoder;
	
	@Test
	public void insertMembers() {
		for (int i = 1; i < 100; i++) {
			String id = "user" + Integer.toString(i);
			String pw = encoder.encode("pw" + Integer.toString(i));
			String name = "name" + Integer.toString(i);
			String phone = "0101234000" + Integer.toString(i);
			String email = "test" + Integer.toString(i) + "@test.com";
			
			Member member = new Member();
			member.setUserId(id);
			member.setUserPw(pw);
			member.setUserName(name);
			member.setPhoneNumber(phone);
			member.setEmail(email);
			
			memberMapper.insertMember(member);
			memberMapper.insertAuthority(new MemberAuthority(member.getUserId(), "ROLE_MEMBER"));
		}
	}
}
